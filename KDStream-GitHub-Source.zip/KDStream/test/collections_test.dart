import 'package:flutter_test/flutter_test.dart';
import 'package:kd_stream/catalog.dart';
import 'package:kd_stream/collections.dart';

void main() {
  test('Explicit episode patterns are grouped and sorted by season', () {
    final items = [
      const MediaItem(
        'Show S02E01',
        'مسلسلات أجنبية',
        'http://example.com/3',
        '',
      ),
      const MediaItem(
        'Show S01E02',
        'مسلسلات أجنبية',
        'http://example.com/2',
        '',
      ),
      const MediaItem(
        'Show S01E01',
        'مسلسلات أجنبية',
        'http://example.com/1',
        '',
      ),
    ];
    final grouped = collectMedia(items);
    expect(grouped.length, 1);
    expect(grouped.single.title, 'Show');
    expect(grouped.single.items.map((i) => episodeInfo(i)!.season), [1, 1, 2]);
    expect(grouped.single.items.first.url, 'http://example.com/1');
  });
  test('Arabic numerals, movie years and group boundaries', () {
    const arabic = MediaItem(
      'المسلسل الموسم ٢ الحلقة ٣',
      'مسلسلات',
      'http://e.com/1',
      '',
    );
    expect(episodeInfo(arabic)!.season, 2);
    expect(episodeInfo(arabic)!.episode, 3);
    const movie = MediaItem('Movie 2026', 'أفلام', 'http://e.com/2', '');
    expect(episodeInfo(movie), isNull);
    expect(collectMedia([arabic, movie]).length, 2);
    expect(
      collectMedia([
        const MediaItem('Show S01E01', 'مسلسلات مترجمة', 'http://e.com/3', ''),
        const MediaItem('Show S01E02', 'مسلسلات مدبلجة', 'http://e.com/4', ''),
      ]).length,
      2,
    );
  });
}
