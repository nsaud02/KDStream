import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:kd_stream/catalog.dart';

void main() {
  test('Read a real HTTP M3U through a relative redirect', () async {
    final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      if (request.uri.path == '/redirect') {
        request.response.statusCode = 302;
        request.response.headers.set('location', '/list');
      } else {
        request.response.write(
          '#EXTM3U\n#EXTINF:-1,Demo\nhttp://example.com/movie.mp4\n',
        );
      }
      await request.response.close();
    });
    try {
      final text = await fetchText('http://127.0.0.1:${server.port}/redirect');
      expect(parseM3u(text).items.single.title, 'Demo');
    } finally {
      await server.close(force: true);
    }
  });
  test(
    'Do not forward Bearer token to a redirected different origin',
    () async {
      final target = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      final source = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      String? received;
      target.listen((request) async {
        received = request.headers.value('authorization');
        request.response.write('done');
        await request.response.close();
      });
      source.listen((request) async {
        request.response.statusCode = 302;
        request.response.headers.set(
          'location',
          'http://127.0.0.1:${target.port}/',
        );
        await request.response.close();
      });
      try {
        expect(
          await fetchText('http://127.0.0.1:${source.port}/', token: 'private'),
          'done',
        );
        expect(received, isNull);
      } finally {
        await source.close(force: true);
        await target.close(force: true);
      }
    },
  );
}
