import 'package:flutter_test/flutter_test.dart';
import 'package:kd_stream/catalog.dart';

void main() {
  test('HTTP and HTTPS work, unsupported schemes do not', () {
    expect(requireMediaUrl('http://example.com/a').scheme, 'http');
    expect(requireMediaUrl('https://example.com/a').scheme, 'https');
    expect(() => requireMediaUrl('file:///etc/passwd'), throwsFormatException);
    expect(() => requireMediaUrl('not a url'), throwsFormatException);
  });
  test('Parse metadata, quoted commas, mixed URLs and deduplicate', () {
    final c = parseM3u('''#EXTM3U
#EXTINF:-1 group-title="أفلام, عربية" tvg-logo="http://example.com/p.jpg",عنوان, كامل
http://example.com/1.mp4
#EXTINF:-1 group-title="مسلسلات",حلقة
https://example.com/2.mp4
#EXTINF:-1,duplicate
http://example.com/1.mp4
#EXTINF:-1,invalid
ftp://example.com/file
''');
    expect(c.items.length, 2);
    expect(c.items.first.title, 'عنوان, كامل');
    expect(c.items.first.logo, 'http://example.com/p.jpg');
    expect(c.items.first.kind, 'أفلام');
    expect(c.items.last.kind, 'مسلسلات');
    expect(c.blocked, 1);
  });
  test('Reject server HTML or JSON responses masquerading as M3U', () {
    expect(() => parseM3u('<html>expired</html>'), throwsFormatException);
  });
}
