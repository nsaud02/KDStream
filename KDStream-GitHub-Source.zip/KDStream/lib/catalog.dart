import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';

Uri requireMediaUrl(String value) {
  final uri = Uri.tryParse(value.trim());
  if (uri == null ||
      !['http', 'https'].contains(uri.scheme) ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty ||
      uri.hasFragment) {
    throw const FormatException('يلزم رابط HTTP أو HTTPS صالح.');
  }
  return uri;
}

// Follow redirects without forwarding authorization across origins.
Future<String> fetchText(String url, {String? token}) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
  try {
    var uri = requireMediaUrl(url);
    HttpClientResponse? result;
    for (var hop = 0; hop <= 5; hop++) {
      final request = await client
          .getUrl(uri)
          .timeout(const Duration(seconds: 25));
      request.followRedirects = false;
      if (token != null &&
          token.isNotEmpty &&
          uri.origin == requireMediaUrl(url).origin) {
        request.headers.set('Authorization', 'Bearer $token');
      }
      final response = await request.close().timeout(
        const Duration(seconds: 25),
      );
      if ([301, 302, 303, 307, 308].contains(response.statusCode)) {
        final location = response.headers.value(HttpHeaders.locationHeader);
        if (location == null || hop == 5)
          throw const HttpException('تعذر متابعة تحويل المصدر.');
        uri = requireMediaUrl(uri.resolve(location).toString());
        await response.drain<void>();
        continue;
      }
      if (response.statusCode != 200) {
        throw HttpException('تعذر الاتصال: HTTP ${response.statusCode}');
      }
      result = response;
      break;
    }
    if (result == null) throw const HttpException('المصدر لم يستجب.');
    final response = result;
    final bytes = <int>[];
    await for (final chunk in response.timeout(const Duration(seconds: 25))) {
      bytes.addAll(chunk);
      if (bytes.length > 64 * 1024 * 1024)
        throw const FormatException('القائمة أكبر من 64 ميجابايت.');
    }
    return utf8.decode(bytes, allowMalformed: true);
  } finally {
    client.close(force: true);
  }
}

class MediaItem {
  final String title, group, url, logo;
  const MediaItem(this.title, this.group, this.url, this.logo);
  String get id => sha256.convert(utf8.encode(url)).toString();
  String get kind {
    final g = group.toLowerCase();
    if (g.contains('مسلسل') || g.contains('series')) return 'مسلسلات';
    if (g.contains('فلام') || g.contains('movie') || g.contains('film'))
      return 'أفلام';
    return 'مباشر';
  }
}

class Catalog {
  final List<MediaItem> items;
  final int blocked;
  const Catalog(this.items, this.blocked);
}

Catalog parseM3u(String source) {
  if (!source.replaceFirst('\uFEFF', '').trimLeft().startsWith('#EXTM3U')) {
    throw const FormatException('الاستجابة ليست قائمة M3U.');
  }
  final items = <MediaItem>[];
  final seen = <String>{};
  String? info;
  var blocked = 0;
  for (final raw in const LineSplitter().convert(source)) {
    final line = raw.trim();
    if (line.startsWith('#EXTINF:')) {
      info = line;
      continue;
    }
    if (line.isEmpty || line.startsWith('#') || info == null) continue;
    final attrs = <String, String>{};
    for (final m in RegExp(r'([\w-]+)="([^"]*)"').allMatches(info)) {
      attrs[m[1]!] = m[2]!;
    }
    // A comma inside an attribute must not split the display title.
    var quoted = false;
    var comma = -1;
    for (var i = 0; i < info.length; i++) {
      if (info[i] == '"') quoted = !quoted;
      if (info[i] == ',' && !quoted) {
        comma = i;
        break;
      }
    }
    final title = comma >= 0 ? info.substring(comma + 1).trim() : 'بدون عنوان';
    info = null;
    try {
      requireMediaUrl(line);
    } on FormatException {
      blocked++;
      continue;
    }
    final logo = attrs['tvg-logo'] ?? '';
    String safeLogo = '';
    try {
      safeLogo = requireMediaUrl(logo).toString();
    } on FormatException {
      /* omit invalid artwork */
    }
    if (seen.add(line))
      items.add(
        MediaItem(title, attrs['group-title'] ?? 'أخرى', line, safeLogo),
      );
  }
  return Catalog(items, blocked);
}

Future<Catalog> loadCatalog(String source, bool remote, String token) async {
  var playlist = source;
  if (remote) {
    final data = jsonDecode(await fetchText(source, token: token));
    if (data is! Map || data['playlist_url'] is! String) {
      throw const FormatException('ملف الإعداد يجب أن يحتوي playlist_url.');
    }
    playlist = data['playlist_url'] as String;
  }
  return parseM3u(await fetchText(playlist));
}
