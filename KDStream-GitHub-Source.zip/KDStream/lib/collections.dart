import 'catalog.dart';

class EpisodeInfo {
  final String series;
  final int season, episode;
  const EpisodeInfo(this.series, this.season, this.episode);
}

EpisodeInfo? episodeInfo(MediaItem item) {
  if (item.kind != 'مسلسلات') return null;
  // Only group explicit season/episode patterns, never infer from trailing years.
  final patterns = [
    RegExp(
      r'^(.*?)\s*[-._ ]*S(\d{1,3})\s*[-._ ]*E(\d{1,4})(?:\b|[ _.-])',
      caseSensitive: false,
    ),
    RegExp(
      r'^(.*?)\s*[-._ ]*(\d{1,3})x(\d{1,4})(?:\b|[ _.-])',
      caseSensitive: false,
    ),
    RegExp(
      r'^(.*?)\s*[-._ ]*(?:الموسم|موسم)\s*(\d{1,3})\s*[-._ ]*(?:الحلقة|حلقة)\s*(\d{1,4})(?:\b|[ _.-])',
    ),
  ];
  final normalized = item.title.replaceAllMapped(
    RegExp('[٠-٩]'),
    (m) => '٠١٢٣٤٥٦٧٨٩'.indexOf(m[0]!).toString(),
  );
  for (final pattern in patterns) {
    final m = pattern.firstMatch(normalized);
    if (m != null && m[1]!.trim().isNotEmpty) {
      return EpisodeInfo(m[1]!.trim(), int.parse(m[2]!), int.parse(m[3]!));
    }
  }
  return null;
}

class MediaCollection {
  final String title;
  final List<MediaItem> items;
  const MediaCollection(this.title, this.items);
  MediaItem get cover => items.first;
  bool get isSeries => episodeInfo(cover) != null;
}

List<MediaCollection> collectMedia(List<MediaItem> items) {
  final grouped = <String, MediaCollection>{};
  for (final item in items) {
    final episode = episodeInfo(item);
    final key = episode == null
        ? item.id
        : '${item.group}\u0000${episode.series.toLowerCase()}';
    grouped
        .putIfAbsent(
          key,
          () => MediaCollection(episode?.series ?? item.title, []),
        )
        .items
        .add(item);
  }
  for (final collection in grouped.values) {
    if (!collection.isSeries) continue;
    collection.items.sort((a, b) {
      final x = episodeInfo(a)!, y = episodeInfo(b)!;
      final season = x.season.compareTo(y.season);
      return season != 0 ? season : x.episode.compareTo(y.episode);
    });
  }
  return grouped.values.toList();
}
