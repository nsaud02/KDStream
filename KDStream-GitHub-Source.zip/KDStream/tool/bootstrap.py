"""Generate Flutter platform scaffolding and configure HTTP/HTTPS playback."""
from pathlib import Path
import plistlib
import subprocess
import xml.etree.ElementTree as ET

subprocess.run(['flutter', 'create', '--platforms=android,ios', '--org', 'com.kd', '--project-name', 'kd_stream', '.'], check=True)
# Generated sample tests do not describe this application.
Path('test/widget_test.dart').unlink(missing_ok=True)
ns = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ns)
path = Path('android/app/src/main/AndroidManifest.xml')
tree = ET.parse(path)
root = tree.getroot()
if not any(e.get(f'{{{ns}}}name') == 'android.permission.INTERNET' for e in root.findall('uses-permission')):
    ET.SubElement(root, 'uses-permission', {f'{{{ns}}}name': 'android.permission.INTERNET'})
app = root.find('application')
app.set(f'{{{ns}}}label', 'KD Stream')
app.set(f'{{{ns}}}usesCleartextTraffic', 'true')
app.set(f'{{{ns}}}allowBackup', 'false')
tree.write(path, encoding='utf-8', xml_declaration=True)
path = Path('ios/Runner/Info.plist')
data = plistlib.loads(path.read_bytes())
data['CFBundleDisplayName'] = 'KD Stream'
data['NSAppTransportSecurity'] = {'NSAllowsArbitraryLoads': True, 'NSAllowsArbitraryLoadsForMedia': True}
path.write_bytes(plistlib.dumps(data))
print('Android and iOS configured for HTTP and HTTPS.')
