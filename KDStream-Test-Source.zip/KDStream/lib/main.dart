import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'catalog.dart';
import 'collections.dart';

void main() => runApp(const KDApp());
const accent = Color(0xFF24E7AF);
const defaultPlaylist = String.fromEnvironment('KD_TEST_PLAYLIST');

class KDApp extends StatelessWidget {
  const KDApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'KD Stream',
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF090C12),
      colorScheme: ColorScheme.fromSeed(
        seedColor: accent,
        brightness: Brightness.dark,
      ),
      cardTheme: const CardThemeData(color: Color(0xFF141B27)),
    ),
    home: const LibraryPage(),
  );
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  final storage = const FlutterSecureStorage();
  final search = TextEditingController();
  Catalog catalog = const Catalog([], 0);
  Set<String> favorites = {};
  Set<String> inProgress = {};
  Map<String, int> lastSeen = {};
  String tab = 'الكل', group = 'الكل', query = '', error = '';
  bool loading = false;
  @override
  void initState() {
    super.initState();
    restore();
  }

  Future<void> restore() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => favorites = (p.getStringList('favorites') ?? []).toSet());
    await readProgress();
    await refresh();
  }

  Future<void> readProgress() async {
    final p = await SharedPreferences.getInstance();
    final ids = <String>{};
    final recent = <String, int>{};
    for (final key in p.getKeys().where((k) => k.startsWith('position:'))) {
      final id = key.substring(9);
      final position = p.getInt(key) ?? 0;
      final duration = p.getInt('duration:$id') ?? 0;
      if (position > 0 && duration > position + 15) ids.add(id);
      recent[id] = p.getInt('seen:$id') ?? 0;
    }
    if (mounted)
      setState(() {
        inProgress = ids;
        lastSeen = recent;
      });
  }

  Future<void> details(MediaCollection collection) async {
    await Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => DetailsPage(collection: collection)),
    );
    await readProgress();
  }

  Future<void> refresh() async {
    if (loading) return;
    setState(() {
      loading = true;
      error = '';
    });
    try {
      final savedSource = await storage.read(key: 'source');
      final source = savedSource == null || savedSource.isEmpty
          ? defaultPlaylist
          : savedSource;
      if (source.isEmpty) return;
      final remote =
          savedSource != null &&
          savedSource.isNotEmpty &&
          await storage.read(key: 'remote') == 'true';
      final result = await loadCatalog(
        source,
        remote,
        await storage.read(key: 'token') ?? '',
      );
      if (mounted)
        setState(() {
          catalog = result;
          group = 'الكل';
        });
    } catch (e) {
      if (mounted)
        setState(
          () => error = e is FormatException
              ? e.message.toString()
              : 'تعذر تحميل القائمة. تحقق من الرابط وصلاحية الاشتراك والاتصال.',
        );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> settings() async {
    final source = TextEditingController(
      text: await storage.read(key: 'source') ?? '',
    );
    final token = TextEditingController(
      text: await storage.read(key: 'token') ?? '',
    );
    bool remote = await storage.read(key: 'remote') == 'true';
    if (!mounted) {
      source.dispose();
      token.dispose();
      return;
    }
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, update) => AlertDialog(
          title: const Text('مصدر مكتبتك'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'أضف مصدرًا تملك حق الوصول إليه. روابط HTTP وHTTPS مقبولة للقائمة والصور والفيديو.',
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('إعداد عن بُعد JSON'),
                  value: remote,
                  onChanged: (v) => update(() => remote = v),
                ),
                TextField(
                  controller: source,
                  textDirection: TextDirection.ltr,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'M3U / JSON URL',
                  ),
                  obscureText: true,
                ),
                if (remote)
                  TextField(
                    controller: token,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'رمز الوصول الشخصي',
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                try {
                  requireMediaUrl(source.text);
                  Navigator.pop(ctx, true);
                } on FormatException {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('أدخل رابط HTTP أو HTTPS صالحًا'),
                    ),
                  );
                }
              },
              child: const Text('حفظ واتصال'),
            ),
          ],
        ),
      ),
    );
    if (saved == true) {
      await storage.write(key: 'source', value: source.text.trim());
      await storage.write(key: 'token', value: token.text.trim());
      await storage.write(key: 'remote', value: remote.toString());
      await refresh();
    }
    // Dialog transition may still reference controllers; dispose after it completes.
    await Future<void>.delayed(const Duration(milliseconds: 350));
    source.dispose();
    token.dispose();
  }

  Future<void> toggle(MediaItem item) async {
    setState(() {
      if (!favorites.add(item.id)) favorites.remove(item.id);
    });
    final p = await SharedPreferences.getInstance();
    await p.setStringList('favorites', favorites.toList());
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = catalog.items
        .where(
          (m) =>
              (tab == 'الكل' ||
                  (tab == 'المفضلة'
                      ? favorites.contains(m.id)
                      : tab == 'متابعة المشاهدة'
                      ? inProgress.contains(m.id)
                      : m.kind == tab)) &&
              (group == 'الكل' || m.group == group) &&
              m.title.toLowerCase().contains(query.toLowerCase()),
        )
        .toList();
    if (tab == 'متابعة المشاهدة') {
      filtered.sort(
        (a, b) => (lastSeen[b.id] ?? 0).compareTo(lastSeen[a.id] ?? 0),
      );
    }
    final collections = collectMedia(filtered);
    final groups = catalog.items.map((e) => e.group).toSet().toList()..sort();
    groups.remove('الكل');
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Text(
              'KD',
              style: TextStyle(
                color: accent,
                fontWeight: FontWeight.w900,
                fontSize: 28,
              ),
            ),
            SizedBox(width: 8),
            Text('STREAM', style: TextStyle(letterSpacing: 3, fontSize: 14)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: loading ? null : refresh,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(onPressed: settings, icon: const Icon(Icons.tune)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(26),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF123A3D),
                            Color(0xFF192035),
                            Color(0xFF10141E),
                          ],
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'عالمك. على شاشتك.',
                            style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            'أفلام، مسلسلات ولحظات تستحق المشاهدة',
                            style: TextStyle(color: Colors.white70),
                          ),
                          const SizedBox(height: 20),
                          FilledButton.icon(
                            onPressed: settings,
                            icon: const Icon(Icons.video_library_outlined),
                            label: const Text('إدارة مكتبتك'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: search,
                      onChanged: (v) => setState(() => query = v),
                      decoration: InputDecoration(
                        hintText: 'ابحث عن عنوانك القادم',
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children:
                            [
                                  'الكل',
                                  'أفلام',
                                  'مسلسلات',
                                  'مباشر',
                                  'متابعة المشاهدة',
                                  'المفضلة',
                                ]
                                .map(
                                  (t) => Padding(
                                    padding: const EdgeInsetsDirectional.only(
                                      end: 8,
                                    ),
                                    child: ChoiceChip(
                                      label: Text(t),
                                      selected: tab == t,
                                      onSelected: (_) =>
                                          setState(() => tab = t),
                                    ),
                                  ),
                                )
                                .toList(),
                      ),
                    ),
                    if (groups.isNotEmpty)
                      DropdownButton<String>(
                        value: group,
                        isExpanded: true,
                        items: ['الكل', ...groups]
                            .map(
                              (g) => DropdownMenuItem(
                                value: g,
                                child: Text(g, overflow: TextOverflow.ellipsis),
                              ),
                            )
                            .toList(),
                        onChanged: (v) => setState(() => group = v ?? 'الكل'),
                      ),
                    if (loading) const LinearProgressIndicator(),
                    if (error.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          error,
                          style: const TextStyle(color: Colors.orangeAccent),
                        ),
                      ),
                    if (catalog.blocked > 0)
                      Text(
                        'حُجب ${catalog.blocked} رابط تشغيل لعدم صلاحيتها.',
                        style: const TextStyle(color: Colors.orangeAccent),
                      ),
                    const SizedBox(height: 14),
                    Text(
                      '${collections.length} عنوان متاح',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (!loading && filtered.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 28),
                        child: Text(
                          'لا توجد عناوين هنا. أضف مصدرك أو غيّر البحث والتصنيف.',
                        ),
                      ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
              sliver: SliverLayoutBuilder(
                builder: (ctx, constraints) => SliverGrid(
                  delegate: SliverChildBuilderDelegate((ctx, i) {
                    final collection = collections[i];
                    final m = collection.cover;
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => details(collection),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(16),
                                  child: m.logo.isEmpty
                                      ? const PosterPlaceholder()
                                      : Image.network(
                                          m.logo,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, e, s) =>
                                              const PosterPlaceholder(),
                                        ),
                                ),
                                Positioned(
                                  top: 4,
                                  left: 4,
                                  child: IconButton.filledTonal(
                                    onPressed: () => toggle(m),
                                    icon: Icon(
                                      favorites.contains(m.id)
                                          ? Icons.favorite
                                          : Icons.favorite_border,
                                      size: 20,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            collection.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text(
                            collection.isSeries
                                ? '${collection.items.length} حلقة • ${m.group}'
                                : m.group,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white54,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    );
                  }, childCount: collections.length),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: (constraints.crossAxisExtent / 160)
                        .floor()
                        .clamp(2, 6),
                    childAspectRatio: .57,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 20,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PosterPlaceholder extends StatelessWidget {
  const PosterPlaceholder({super.key});
  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF17232D),
    child: const Center(
      child: Icon(Icons.play_circle_outline, size: 48, color: accent),
    ),
  );
}

class PlayerPage extends StatefulWidget {
  final MediaItem item;
  const PlayerPage({super.key, required this.item});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> with WidgetsBindingObserver {
  VideoPlayerController? controller;
  String error = '';
  Timer? progressTimer;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    open();
  }

  Future<void> open() async {
    try {
      final c = VideoPlayerController.networkUrl(
        requireMediaUrl(widget.item.url),
      );
      controller = c;
      await c.initialize().timeout(const Duration(seconds: 30));
      if (!mounted) return;
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      final position = p.getInt('position:${widget.item.id}') ?? 0;
      if (position > 0 && position < c.value.duration.inSeconds - 10)
        await c.seekTo(Duration(seconds: position));
      if (!mounted) return;
      await c.play();
      if (!mounted) return;
      progressTimer = Timer.periodic(
        const Duration(seconds: 10),
        (_) => save(),
      );
      setState(() {});
    } catch (_) {
      if (mounted)
        setState(
          () => error =
              'تعذر التشغيل. قد يكون الرابط منتهيًا أو التنسيق غير مدعوم.',
        );
    }
  }

  Future<void> save() async {
    final c = controller;
    if (c == null || !c.value.isInitialized) return;
    final position = c.value.position.inSeconds;
    final duration = c.value.duration.inSeconds;
    final p = await SharedPreferences.getInstance();
    await p.setInt('position:${widget.item.id}', position);
    await p.setInt('duration:${widget.item.id}', duration);
    await p.setInt(
      'seen:${widget.item.id}',
      DateTime.now().millisecondsSinceEpoch,
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      controller?.pause();
      save();
    }
  }

  @override
  void dispose() {
    progressTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    save();
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Scaffold(
      appBar: AppBar(title: Text(widget.item.title)),
      body: Center(
        child: error.isNotEmpty
            ? Padding(padding: const EdgeInsets.all(24), child: Text(error))
            : c == null || !c.value.isInitialized
            ? const CircularProgressIndicator()
            : ValueListenableBuilder<VideoPlayerValue>(
                valueListenable: c,
                builder: (ctx, value, _) => Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AspectRatio(
                      aspectRatio: value.aspectRatio > 0
                          ? value.aspectRatio
                          : 16 / 9,
                      child: VideoPlayer(c),
                    ),
                    VideoProgressIndicator(
                      c,
                      allowScrubbing: true,
                      padding: const EdgeInsets.all(16),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: () => c.seekTo(
                            value.position - const Duration(seconds: 10),
                          ),
                          icon: const Icon(Icons.replay_10),
                        ),
                        IconButton(
                          onPressed: () =>
                              value.isPlaying ? c.pause() : c.play(),
                          iconSize: 48,
                          icon: Icon(
                            value.isPlaying
                                ? Icons.pause_circle
                                : Icons.play_circle,
                            color: accent,
                          ),
                        ),
                        IconButton(
                          onPressed: () => c.seekTo(
                            value.position + const Duration(seconds: 10),
                          ),
                          icon: const Icon(Icons.forward_10),
                        ),
                      ],
                    ),
                    if (value.hasError)
                      const Text('توقف التشغيل. تحقق من المصدر والاتصال.'),
                  ],
                ),
              ),
      ),
    );
  }
}

class DetailsPage extends StatefulWidget {
  final MediaCollection collection;
  const DetailsPage({super.key, required this.collection});
  @override
  State<DetailsPage> createState() => _DetailsPageState();
}

class _DetailsPageState extends State<DetailsPage> {
  int? selectedSeason;
  @override
  Widget build(BuildContext context) {
    final collection = widget.collection;
    final cover = collection.cover;
    final seasons =
        collection.items
            .map(episodeInfo)
            .whereType<EpisodeInfo>()
            .map((e) => e.season)
            .toSet()
            .toList()
          ..sort();
    final current = selectedSeason ?? (seasons.isEmpty ? null : seasons.first);
    final episodes = collection.items
        .where((m) => current == null || episodeInfo(m)?.season == current)
        .toList();
    Future<void> play(MediaItem item) => Navigator.push<void>(
      context,
      MaterialPageRoute(builder: (_) => PlayerPage(item: item)),
    );
    return Scaffold(
      appBar: AppBar(title: Text(collection.title)),
      body: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          Container(
            height: 280,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: const Color(0xFF17232D),
            ),
            child: cover.logo.isEmpty
                ? const PosterPlaceholder()
                : Image.network(
                    cover.logo,
                    fit: BoxFit.contain,
                    errorBuilder: (_, e, s) => const PosterPlaceholder(),
                  ),
          ),
          const SizedBox(height: 22),
          Text(
            collection.title,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          Text(cover.group, style: const TextStyle(color: Colors.white60)),
          const SizedBox(height: 20),
          if (!collection.isSeries)
            FilledButton.icon(
              onPressed: () => play(cover),
              icon: const Icon(Icons.play_arrow),
              label: const Text('تشغيل / استكمال'),
            ),
          if (collection.isSeries) ...[
            Text(
              '${collection.items.length} حلقة • ${seasons.length} موسم',
              style: const TextStyle(color: accent),
            ),
            const SizedBox(height: 14),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: seasons
                    .map(
                      (season) => Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: ChoiceChip(
                          label: Text('الموسم $season'),
                          selected: current == season,
                          onSelected: (_) =>
                              setState(() => selectedSeason = season),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
            const SizedBox(height: 12),
            ...episodes.map(
              (item) => Card(
                child: ListTile(
                  leading: const Icon(Icons.play_circle_outline, color: accent),
                  title: Text('الحلقة ${episodeInfo(item)!.episode}'),
                  subtitle: Text(item.title),
                  onTap: () => play(item),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
